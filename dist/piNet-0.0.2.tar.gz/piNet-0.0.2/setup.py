from setuptools import setup, find_packages


setup(
    name='piNet',
    version='0.0.2',
    license='GNU General Public License',
    author="ineerajrajeev",
    author_email='neerajshetkar@gmail.com',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='https://github.com/ineerajrajeev/pieNet',
    keywords='python to HTML',
    install_requires=[],

)